
Slicebox
=========

Slicebox is  a jQuery 3D image slider plugin that makes use of CSS 3D Transforms and provides a graceful fallback for older browsers that don't support the new properties.

[article on Codrops](http://tympanus.net/codrops/2011/09/05/slicebox-3d-image-slider/)

[demo](http://tympanus.net/Development/Slicebox/)

Licensed under the MIT License